@echo off
cd /d "%~dp0"
echo Agent ishga tushirilmoqda...
python agent.py
pause
