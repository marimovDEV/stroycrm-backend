import requests
import time
from escpos.printer import Win32Raw
from datetime import datetime

# --- SOZLAMALAR ---
# Backend manzili (agar boshqa PC bo'lsa IP ni o'zgartiring: http://192.168.1.X:5000)
# localhost ba'zida muammo bo'lishi mumkin, 127.0.0.1 ishonchliroq
BACKEND_URL = "http://127.0.0.1:5000/api"
PRINTER_NAME = "POS58B"  # Printer nomi
WIDTH = 32

def line(char='-'):
    return char * WIDTH + "\n"

def lr(left, right):
    """Chap va O'ng matnni joylash"""
    left = str(left).strip()
    right = str(right).strip()
    space = WIDTH - len(left) - len(right)
    if space < 1:
        left = left[: max(0, WIDTH - len(right) - 1)]
        space = WIDTH - len(left) - len(right)
        if space < 1: space = 1
    return left + (" " * space) + right + "\n"

def money(amount):
    return f"{amount:,}".replace(",", " ")

def test_printer():
    """Start oldidan printerni tekshirish"""
    try:
        print(f"🖨️ Printerga ulanish: {PRINTER_NAME}...")
        p = Win32Raw(PRINTER_NAME)
        p.text("Agent ishga tushdi!\n\n")
        # Cut (ba'zi POS58B da ishlaydi)
        # p._raw(b"\x1d\x56\x00")
        print("✅ Printer OK! Sinov yozuvi chiqishi kerak.")
        return True
    except Exception as e:
        print(f"❌ Printer Xatosi: {e}")
        print("💡 Maslahat: Printer nomi to'g'riligini va USB ulanganini tekshiring.")
        return False

def print_receipt(job_data):
    try:
        p = Win32Raw(PRINTER_NAME)
    except Exception as e:
        print(f"❌ Printer xatosi: {e}")
        return False

    try:
        print(f"🖨️ Chop etilmoqda: Job ID {job_data.get('check_id', '?')}")
        
        # Header
        p._raw(b"\x1b\x40")          # Init
        p._raw(b"\x1b\x61\x01")      # Center
        p._raw(b"\x1d\x21\x11")      # Double Size
        p.text("TASTE RADAR\n")
        p._raw(b"\x1d\x21\x00")      # Normal
        p.text("Toshkent sh., Chilonzor\n")
        p.text(line('='))

        # Check Info
        p._raw(b"\x1b\x45\x01")      # Bold
        p.text(f"STOL: {job_data.get('table', '-')}\n")
        p._raw(b"\x1b\x45\x00")
        p.text(f"{job_data.get('date')} {job_data.get('time')}\n")
        p.text(line('-'))

        # Items
        p._raw(b"\x1b\x61\x00")      # Left align
        subtotal = 0
        for item in job_data.get('items', []):
            name = item['name']
            price = item['price']
            subtotal += price
            p.text(lr(name, money(price)))
        
        p.text(line('-'))

        # Totals
        qqs = int(round(subtotal * 0.12))
        total = subtotal + qqs
        
        p.text(lr("Jami (QQSsiz):", money(subtotal)))
        p.text(lr("QQS (12%):", money(qqs)))
        p.text(line('='))

        # Grand Total
        p._raw(b"\x1b\x61\x01")      # Center
        p._raw(b"\x1b\x45\x01")      # Bold
        p._raw(b"\x1d\x21\x01")      # Double Height
        p.text(f"JAMI: {money(total)}\n")
        p._raw(b"\x1d\x21\x00")
        p._raw(b"\x1b\x45\x00")

        # Footer
        p.text("\nXaridingiz uchun rahmat!\n")
        p.text("www.tasteradar.uz\n\n\n")
        
        # Cut
        p._raw(b"\x1d\x56\x00")
        
        # Printer bilan ishlashni to'xtatish (muhim!)
        p.close()
        
        print("✅ Muvaffaqiyatli chop etildi!")
        return True

    except Exception as e:
        print(f"❌ Chop etish jarayonida xatolik: {e}")
        return False

def main():
    print(f"🚀 Agent ishga tushdi...")
    print(f"📡 Backend: {BACKEND_URL}")
    
    # Start Test
    if not test_printer():
        print("⚠️ Printer ishlamadi, lekin davom etamiz...")

    print("⏳ Kutish rejimi...")
    
    while True:
        try:
            # 1. Yangi vazifa bormi?
            resp = requests.get(f"{BACKEND_URL}/poll", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                job = data.get('job')
                
                if job:
                    print(f"📥 Yangi vazifa qabul qilindi: {job['id']}")
                    
                    # 2. Chop etish
                    success = print_receipt(job['data'])
                    
                    # 3. Tasdiqlash
                    if success:
                        requests.post(f"{BACKEND_URL}/ack/{job['id']}")
                    else:
                        print("⚠️ Vazifa bajarilmadi, keyinroq qayta urinib ko'rish mumkin.")
                    
                else:
                    # Vazifa yo'q, jim turamiz (har 2 soniyada so'raydi)
                    time.sleep(2)
            else:
                print(f"⚠️ Server javobi g'alati: {resp.status_code}")
                time.sleep(5)
                
        except requests.exceptions.ConnectionError:
            print("❌ Serverga ulanib bo'lmadi (Backend ishlayaptimi?). Qayta urinish...")
            time.sleep(5)
        except Exception as e:
            print(f"❌ Kutilmagan xato: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
